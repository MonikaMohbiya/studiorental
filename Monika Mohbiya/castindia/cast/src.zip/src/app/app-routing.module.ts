import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Cast1Component } from './cast1/cast1.component';
import { ChatComponent } from './chat/chat.component';

const routes: Routes = [
  { path: 'cast1', component: Cast1Component },
  { path:'', redirectTo: 'cast1-Component', pathMatch: 'full'},
  { path: 'chat', component: ChatComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
