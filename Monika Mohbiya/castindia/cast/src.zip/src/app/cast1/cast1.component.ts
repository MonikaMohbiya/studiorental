import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cast1',
  templateUrl: './cast1.component.html',
  styleUrls: ['./cast1.component.css']
})
export class Cast1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
