import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Cast1Component } from './cast1.component';

describe('Cast1Component', () => {
  let component: Cast1Component;
  let fixture: ComponentFixture<Cast1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Cast1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Cast1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
